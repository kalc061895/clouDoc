<!-- 
 -- MODIFICA AQUI EL FORMATO PARA LOS PDFS
 -- DE REPORTE 
 -->
<!-- CODE HERE -->
<h1>Constancia de Presentación</h1>
<p>N° Expediente: <?= $expediente['numero_expediente'] ?></p>
<p>Nombre: <?= $expediente['entidad_id'] ?></p>
<p>Fecha: <?= $expediente['fecha_recepcion'] ?></p>
<p>Asunto: <?= $expediente['asunto'] ?></p>
