<?php 
return [
    "titleMenu"=> "Configuración de Menu de Sistema",
];