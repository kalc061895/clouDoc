<?php

return [
    'welcomeMessage' => 'Welcome to our application',
    'login' => 'Login',
    'register' => 'Register',
    // Agrega más claves de traducción aquí
];
