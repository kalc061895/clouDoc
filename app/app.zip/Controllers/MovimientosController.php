<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class MovimientosController extends BaseController
{
    public function index()
    {
        
    }
    

}
