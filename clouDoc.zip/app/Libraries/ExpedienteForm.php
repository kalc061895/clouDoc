<?php

namespace App\Libraries;

class ExpedienteForm
{
    public function render()
    {
        return view('components/expediente_form');
    }
}
