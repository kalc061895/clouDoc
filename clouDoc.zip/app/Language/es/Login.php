<?php

return [
    'welcomeMessage' => 'Bienvenido a nuestra aplicación',
    'login' => 'Iniciar sesión',
    'register' => 'Registrarse',
    // Agrega más claves de traducción aquí
];
